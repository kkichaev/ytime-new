<div class="fob-ticksify-wrapper">
    <div class="fob-ticksify-card">
        <h4 class="fob-ticksify-card-title">{{ __('Create Ticket') }}</h4>
        {!! $form->renderForm() !!}
    </div>
</div>
