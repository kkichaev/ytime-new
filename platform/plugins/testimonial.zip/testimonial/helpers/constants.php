<?php

if (! defined('TESTIMONIAL_MODULE_SCREEN_NAME')) {
    define('TESTIMONIAL_MODULE_SCREEN_NAME', 'testimonial');
}
