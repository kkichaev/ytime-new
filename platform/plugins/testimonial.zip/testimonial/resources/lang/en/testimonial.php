<?php

return [
    'name' => 'Testimonials',
    'description' => 'Manage your system testimonials',
    'create' => 'New testimonial',
    'company' => 'Position/Company',
];
