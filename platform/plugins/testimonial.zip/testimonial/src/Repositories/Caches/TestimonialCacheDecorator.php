<?php

namespace Botble\Testimonial\Repositories\Caches;

use Botble\Testimonial\Repositories\Eloquent\TestimonialRepository;

/**
 * @deprecated
 */
class TestimonialCacheDecorator extends TestimonialRepository
{
}
