<?php

namespace Botble\Testimonial\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface TestimonialInterface extends RepositoryInterface
{
}
