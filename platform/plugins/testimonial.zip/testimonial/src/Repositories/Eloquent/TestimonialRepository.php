<?php

namespace Botble\Testimonial\Repositories\Eloquent;

use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;
use Botble\Testimonial\Repositories\Interfaces\TestimonialInterface;

class TestimonialRepository extends RepositoriesAbstract implements TestimonialInterface
{
}
