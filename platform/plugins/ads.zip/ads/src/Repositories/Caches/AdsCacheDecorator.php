<?php

namespace Botble\Ads\Repositories\Caches;

use Botble\Ads\Repositories\Eloquent\AdsRepository;

/**
 * @deprecated
 */
class AdsCacheDecorator extends AdsRepository
{
}
