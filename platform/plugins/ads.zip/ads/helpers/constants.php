<?php

if (! defined('ADS_MODULE_SCREEN_NAME')) {
    define('ADS_MODULE_SCREEN_NAME', 'ads');
}
