<?php

return [
    'use_real_image_url' => env('CMS_ADS_USE_REAL_IMAGE_URL', true),
];
