<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
</script>
