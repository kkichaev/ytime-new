<x-core::alert type="warning" class="approve-product-warning">
    {!! BaseHelper::clean(trans('plugins/ads::ads.adblock_warning')) !!}
</x-core::alert>
