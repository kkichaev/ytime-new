@php
    $layout = 'plugins/member::themes.dashboard.layouts.master';
@endphp

@extends('core/table::table')

@section('content')
    @parent
@stop
