@php
    $layout = 'plugins/member::themes.dashboard.layouts.master';
@endphp

@extends('core/base::forms.form')

@section('content')
    @parent
@stop
