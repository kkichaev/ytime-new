<div class="mb-3">
    <x-core::button type="submit" color="primary">
        {{ $label }}
    </x-core::button>
</div>
