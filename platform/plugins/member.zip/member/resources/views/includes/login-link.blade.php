<div class="mt-3 text-center">
    {{ __('Already have an account?') }}
    <a href="{{ route('public.member.login') }}" class="text-decoration-underline">
        {{ __('Login') }}
    </a>
</div>
