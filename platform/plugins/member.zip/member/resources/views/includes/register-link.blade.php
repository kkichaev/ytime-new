<div class="mt-3 text-center">
    {{ __("Don't have an account?") }}
    <a href="{{ route('public.member.register') }}" class="text-decoration-underline">
        {{ __('Register now') }}
    </a>
</div>
