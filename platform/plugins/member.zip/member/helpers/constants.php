<?php

if (! defined('MEMBER_MODULE_SCREEN_NAME')) {
    define('MEMBER_MODULE_SCREEN_NAME', 'member');
}

if (! defined('MEMBER_TOP_MENU_FILTER')) {
    define('MEMBER_TOP_MENU_FILTER', 'member-top-menu');
}

if (! defined('MEMBER_TOP_STATISTIC_FILTER')) {
    define('MEMBER_TOP_STATISTIC_FILTER', 'member-top-statistic');
}
