<?php

namespace Botble\Member\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface MemberInterface extends RepositoryInterface
{
}
