<?php

namespace Botble\Member\Repositories\Eloquent;

use Botble\Member\Repositories\Interfaces\MemberInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class MemberRepository extends RepositoriesAbstract implements MemberInterface
{
}
