<?php

namespace Botble\Member\Repositories\Caches;

use Botble\Member\Repositories\Eloquent\MemberActivityLogRepository;

/**
 * @deprecated
 */
class MemberActivityLogCacheDecorator extends MemberActivityLogRepository
{
}
