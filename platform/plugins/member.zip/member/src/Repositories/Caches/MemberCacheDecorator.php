<?php

namespace Botble\Member\Repositories\Caches;

use Botble\Member\Repositories\Eloquent\MemberRepository;

/**
 * @deprecated
 */
class MemberCacheDecorator extends MemberRepository
{
}
