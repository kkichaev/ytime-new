<?php

namespace Botble\Member\Forms\Fronts\Auth\FieldOptions;

use Botble\Base\Forms\FieldOptions\TextFieldOption as BaseTextFieldOption;

class TextFieldOption extends BaseTextFieldOption
{
    use HasIcon;
}
