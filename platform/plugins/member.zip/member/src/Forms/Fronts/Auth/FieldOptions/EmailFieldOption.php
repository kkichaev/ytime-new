<?php

namespace Botble\Member\Forms\Fronts\Auth\FieldOptions;

use Botble\Base\Forms\FieldOptions\EmailFieldOption as BaseEmailFieldOption;

class EmailFieldOption extends BaseEmailFieldOption
{
    use HasIcon;
}
