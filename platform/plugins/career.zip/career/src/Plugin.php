<?php

namespace ArchiElite\Career;

use Botble\PluginManagement\Abstracts\PluginOperationAbstract;
use Illuminate\Support\Facades\Schema;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Schema::dropIfExists('careers');
        Schema::dropIfExists('careers_translations');
    }
}
