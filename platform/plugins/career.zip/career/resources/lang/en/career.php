<?php

return [
    'name' => 'Careers',
    'careers' => 'Careers',
    'create' => 'New career',
    'location' => 'Location',
    'salary' => 'Salary',
    'edit_career' => 'Edit this career',
];
