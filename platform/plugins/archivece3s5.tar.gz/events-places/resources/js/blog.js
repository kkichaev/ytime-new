$(() => {
    'use strict'

    BDashboard.loadWidget($('#widget_posts_recent').find('.widget-content'), $('#widget_posts_recent').data('url'))
})
