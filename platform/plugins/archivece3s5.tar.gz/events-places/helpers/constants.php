<?php

if (! defined('POST_MODULE_SCREEN_NAME')) {
    define('POST_MODULE_SCREEN_NAME', 'post');
}

if (! defined('CATEGORY_MODULE_SCREEN_NAME')) {
    define('CATEGORY_MODULE_SCREEN_NAME', 'category');
}

if (! defined('TAG_MODULE_SCREEN_NAME')) {
    define('TAG_MODULE_SCREEN_NAME', 'tag');
}

if (! defined('MEMBER_POST_MODULE_SCREEN_NAME')) {
    define('MEMBER_POST_MODULE_SCREEN_NAME', 'member-post');
}

// Change data search result
if (! defined('BASE_FILTER_SET_DATA_SEARCH')) {
    define('BASE_FILTER_SET_DATA_SEARCH', 'set_data_search');
}
