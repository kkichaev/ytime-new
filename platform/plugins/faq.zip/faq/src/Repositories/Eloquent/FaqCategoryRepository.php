<?php

namespace Botble\Faq\Repositories\Eloquent;

use Botble\Faq\Repositories\Interfaces\FaqCategoryInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class FaqCategoryRepository extends RepositoriesAbstract implements FaqCategoryInterface
{
}
