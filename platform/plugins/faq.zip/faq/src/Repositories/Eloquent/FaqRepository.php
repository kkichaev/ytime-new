<?php

namespace Botble\Faq\Repositories\Eloquent;

use Botble\Faq\Repositories\Interfaces\FaqInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class FaqRepository extends RepositoriesAbstract implements FaqInterface
{
}
