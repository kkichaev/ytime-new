<?php

namespace Botble\Faq\Repositories\Caches;

use Botble\Faq\Repositories\Eloquent\FaqCategoryRepository;

/**
 * @deprecated
 */
class FaqCategoryCacheDecorator extends FaqCategoryRepository
{
}
