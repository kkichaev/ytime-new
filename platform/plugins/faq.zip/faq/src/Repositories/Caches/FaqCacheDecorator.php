<?php

namespace Botble\Faq\Repositories\Caches;

use Botble\Faq\Repositories\Eloquent\FaqRepository;

/**
 * @deprecated
 */
class FaqCacheDecorator extends FaqRepository
{
}
