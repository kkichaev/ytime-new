<?php

return [
    'schema_supported' => [
        'Botble\Page\Models\Page',
        'Botble\Blog\Models\Post',
    ],
];
