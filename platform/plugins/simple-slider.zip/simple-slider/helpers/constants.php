<?php

if (! defined('SIMPLE_SLIDER_MODULE_SCREEN_NAME')) {
    define('SIMPLE_SLIDER_MODULE_SCREEN_NAME', 'simple-slider');
}

if (! defined('SIMPLE_SLIDER_ITEM_MODULE_SCREEN_NAME')) {
    define('SIMPLE_SLIDER_ITEM_MODULE_SCREEN_NAME', 'simple-slider-item');
}

if (! defined('SIMPLE_SLIDER_VIEW_TEMPLATE')) {
    define('SIMPLE_SLIDER_VIEW_TEMPLATE', 'simple-slider-view-template');
}
