<?php

namespace Botble\SimpleSlider\Repositories\Caches;

use Botble\SimpleSlider\Repositories\Eloquent\SimpleSliderRepository;

/**
 * @deprecated
 */
class SimpleSliderCacheDecorator extends SimpleSliderRepository
{
}
