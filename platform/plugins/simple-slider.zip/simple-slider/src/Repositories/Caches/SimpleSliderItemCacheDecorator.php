<?php

namespace Botble\SimpleSlider\Repositories\Caches;

use Botble\SimpleSlider\Repositories\Eloquent\SimpleSliderItemRepository;

/**
 * @deprecated
 */
class SimpleSliderItemCacheDecorator extends SimpleSliderItemRepository
{
}
