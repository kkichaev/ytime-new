<?php

namespace Botble\SimpleSlider\Repositories\Eloquent;

use Botble\SimpleSlider\Repositories\Interfaces\SimpleSliderItemInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class SimpleSliderItemRepository extends RepositoriesAbstract implements SimpleSliderItemInterface
{
}
