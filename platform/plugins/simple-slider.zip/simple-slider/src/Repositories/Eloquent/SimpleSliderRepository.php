<?php

namespace Botble\SimpleSlider\Repositories\Eloquent;

use Botble\SimpleSlider\Repositories\Interfaces\SimpleSliderInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class SimpleSliderRepository extends RepositoriesAbstract implements SimpleSliderInterface
{
}
