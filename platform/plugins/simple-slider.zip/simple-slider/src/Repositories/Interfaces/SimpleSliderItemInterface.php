<?php

namespace Botble\SimpleSlider\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface SimpleSliderItemInterface extends RepositoryInterface
{
}
