<div class="simple-slider-assets mt-3">
        <pre class="mb-2">
/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.css
/vendor/core/plugins/simple-slider/css/simple-slider.css
/vendor/core/plugins/simple-slider/libraries/owl-carousel/owl.carousel.js
/vendor/core/plugins/simple-slider/js/simple-slider.js</pre>
    <x-core::form.helper-text>
        {{ trans('plugins/simple-slider::simple-slider.settings.using_assets_description') }}
    </x-core::form.helper-text>
</div>
