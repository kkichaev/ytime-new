<?php

namespace Botble\EventsPlaces\Enums;

use Botble\Base\Enums\BaseStatusEnum;

class PostStatusEnum extends BaseStatusEnum
{
}
