<?php

namespace Botble\EventsPlaces\Repositories\Caches;

use Botble\EventsPlaces\Repositories\Eloquent\TagRepository;

/**
 * @deprecated
 */
class TagCacheDecorator extends TagRepository
{
}
