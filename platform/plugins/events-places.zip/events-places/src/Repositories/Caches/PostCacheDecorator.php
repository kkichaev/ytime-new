<?php

namespace Botble\EventsPlaces\Repositories\Caches;

use Botble\EventsPlaces\Repositories\Eloquent\PostRepository;

/**
 * @deprecated
 */
class PostCacheDecorator extends PostRepository
{
}
