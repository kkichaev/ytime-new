<?php

namespace Botble\EventsPlaces\Repositories\Caches;

use Botble\EventsPlaces\Repositories\Eloquent\CategoryRepository;

/**
 * @deprecated
 */
class CategoryCacheDecorator extends CategoryRepository
{
}
