<x-core::icon name="ti ti-cloud-upload" />{{ trans('plugins/custom-field::base.import') }}
