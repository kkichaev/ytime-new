<?php

namespace Botble\CustomField\Repositories\Eloquent;

use Botble\CustomField\Repositories\Interfaces\CustomFieldInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class CustomFieldRepository extends RepositoriesAbstract implements CustomFieldInterface
{
}
