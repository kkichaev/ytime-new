<?php

namespace Botble\CustomField\Repositories\Caches;

use Botble\CustomField\Repositories\Eloquent\FieldGroupRepository;

/**
 * @deprecated
 */
class FieldGroupCacheDecorator extends FieldGroupRepository
{
}
