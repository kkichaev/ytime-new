<?php

namespace Botble\CustomField\Repositories\Caches;

use Botble\CustomField\Repositories\Eloquent\FieldItemRepository;

/**
 * @deprecated
 */
class FieldItemCacheDecorator extends FieldItemRepository
{
}
