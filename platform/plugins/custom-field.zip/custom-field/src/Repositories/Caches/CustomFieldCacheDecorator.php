<?php

namespace Botble\CustomField\Repositories\Caches;

use Botble\CustomField\Repositories\Eloquent\CustomFieldRepository;

/**
 * @deprecated
 */
class CustomFieldCacheDecorator extends CustomFieldRepository
{
}
