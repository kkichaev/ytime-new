<?php

return [
    'supported' => [
        'Botble\Page\Models\Page',
        'Botble\Blog\Models\Post',
        'Botble\Blog\Models\Category',
    ],
];
